# companion-core

桌游 LLM 桌搭子与 ChatBot 共用的最小内核：契约、Prompt 预算、参与策略、回复清洗、OpenAI 兼容 Provider 与评测断言。

约束：纯 TypeScript，不依赖 Node 运行时、数据库、HTTP 服务或 UI；密钥、存储、传输、游戏规则和 ChatBot 领域模型都不在这里。

```bash
npm install
npm test
npm run typecheck
npm run build
```
